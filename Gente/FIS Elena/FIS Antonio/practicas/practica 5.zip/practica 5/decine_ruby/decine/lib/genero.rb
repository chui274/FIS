# encoding: UTF-8
# 
#   Fundamentos de Ingenieria del Software
#   Grado en Ingeniería Informática
#
#   2014 © Copyleft - All Wrongs Reserved
# 
#   Ernesto Serrano <erseco@correo.ugr.es>
#   Carlos Garrancho
#   Pablo Martinez
#

module Decine
  #Creamos una enumeración
  AVENTURA = :AVENTURA
  CIENCIAFICCION = :CIENCIAFICCION
  DRAMA = :DRAMA
  
=begin
  ARMOR=1
  ONEHAND=2
  BOTHHAND=3
  HELMET=4
  SHOE=5
  NECKLACE=6
=end
end