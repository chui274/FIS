#ifndef GENERO
#define GENERO

/*  
 *  Fundamentos de Ingenieria del Software
 *  Grado en Ingeniería Informática
 * 
 *  2014 © Copyleft - All Wrongs Reserved
 *
 *  Ernesto Serrano <erseco@correo.ugr.es>
 *  Carlos Garrancho
 *  Pablo Martinez
 * 
 */
namespace decine {

	enum Genero {
		Aventura,
		CienciaFiccion,
		Drama
	};

}


#endif	//#ifndef GENERO
